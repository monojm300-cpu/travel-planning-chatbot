import re
import streamlit as st

# ============================================================
# CA3 PROJECT: TRAVEL PLANNING CHATBOT
# Student: MANOJ KUMAR J
# Platform: Python + Streamlit
# ============================================================

st.set_page_config(page_title="Travel Planning Chatbot", page_icon="✈️", layout="centered")

DESTINATIONS = {
    "Goa": {
        "budget": 12000,
        "transport": ["Bus", "Train", "Flight"],
        "hotel": "Budget hotels and beachside stays",
        "attractions": ["Baga Beach", "Fort Aguada", "Basilica of Bom Jesus", "Local markets"],
        "food": "Seafood and local Goan cuisine",
        "best_for": ["beaches", "friends", "relaxation", "nightlife"],
    },
    "Manali": {
        "budget": 15000,
        "transport": ["Bus", "Train + Taxi", "Flight + Taxi"],
        "hotel": "Budget hotels and mountain homestays",
        "attractions": ["Hadimba Temple", "Solang Valley", "Mall Road", "Old Manali"],
        "food": "North Indian and Himachali food",
        "best_for": ["mountains", "adventure", "couples", "nature"],
    },
    "Jaipur": {
        "budget": 9000,
        "transport": ["Bus", "Train", "Flight"],
        "hotel": "Budget hotels and heritage guesthouses",
        "attractions": ["Hawa Mahal", "Amber Fort", "City Palace", "Jantar Mantar"],
        "food": "Rajasthani thali and local street food",
        "best_for": ["history", "culture", "architecture", "food"],
    },
    "Kerala": {
        "budget": 16000,
        "transport": ["Bus", "Train", "Flight"],
        "hotel": "Budget hotels, homestays and resorts",
        "attractions": ["Alleppey backwaters", "Munnar tea gardens", "Fort Kochi", "Local spice markets"],
        "food": "Kerala cuisine and traditional meals",
        "best_for": ["nature", "backwaters", "relaxation", "couples"],
    },
    "Ooty": {
        "budget": 8000,
        "transport": ["Bus", "Train + Taxi", "Car"],
        "hotel": "Budget hotels and hill-view homestays",
        "attractions": ["Ooty Botanical Garden", "Ooty Lake", "Doddabetta Peak", "Nilgiri Mountain Railway"],
        "food": "South Indian food and local chocolates",
        "best_for": ["hills", "nature", "families", "relaxation"],
    },
    "Bengaluru": {
        "budget": 7000,
        "transport": ["Bus", "Train", "Flight"],
        "hotel": "Budget hotels and city guesthouses",
        "attractions": ["Lalbagh Botanical Garden", "Cubbon Park", "Bengaluru Palace", "Commercial Street"],
        "food": "South Indian cuisine and local cafes",
        "best_for": ["city sightseeing", "food", "shopping", "families"],
    },
}


def detect_intent(message: str) -> str:
    text = message.lower().strip()
    if re.search(r"\b(bye|goodbye|exit|quit|see you|done)\b", text):
        return "GOODBYE"
    if re.search(r"\b(hello|hi|hey|good morning|good evening)\b", text):
        return "GREETING"
    if re.search(r"\b(itinerary|plan my trip|trip plan|places to visit|day wise|sightseeing|schedule|travel plan)\b", text):
        return "ITINERARY"
    if re.search(r"\b(hotel|hotels|stay|accommodation|resort|homestay|hostel)\b", text):
        return "HOTEL"
    if re.search(r"\b(train|bus|flight|plane|transport|bike|taxi|cab|car)\b", text):
        return "TRANSPORT"
    if re.search(r"\b(budget|cost|price|cheap|afford|rupees|rs\.?|inr|under|below|within)\b", text) or re.search(r"₹\s*\d|\b\d+\s*(?:k|thousand)\b", text):
        return "BUDGET"
    if re.search(r"\b(date|dates|when|month|tomorrow|weekend|january|february|march|april|may|june|july|august|september|october|november|december)\b", text):
        return "DATES"
    if re.search(r"\b(destination|where|visit|go to|travel to|trip to|holiday in|vacation in)\b", text):
        return "DESTINATION"
    return "UNKNOWN"


def extract_entities(message: str) -> dict:
    text = message.strip()
    lower = text.lower()
    entities = {}

    for place in DESTINATIONS:
        if re.search(r"\b" + re.escape(place.lower()) + r"\b", lower):
            entities["Destination"] = place
            break

    # Amount patterns: ₹15000, Rs 15000, 15k, 15 thousand, budget 15000
    patterns = [
        r"(?:₹|rs\.?|inr)\s*([\d,]+(?:\.\d+)?)\s*(k|thousand)?",
        r"\b([\d,]+(?:\.\d+)?)\s*(k|thousand)\b",
        r"\b(?:budget|under|below|within|around|maximum|max|spend|cost)\s*(?:of\s*)?(?:₹|rs\.?|inr)?\s*([\d,]+)"
    ]
    for idx, pattern in enumerate(patterns):
        match = re.search(pattern, lower)
        if match:
            amount = float(match.group(1).replace(",", ""))
            multiplier = 1000 if idx < 2 and len(match.groups()) > 1 and match.group(2) else 1
            amount = int(amount * multiplier)
            if amount >= 1000:
                entities["Budget"] = amount
                break

    duration = re.search(r"\b(\d+)\s*(days?|nights?|weeks?)\b", lower)
    if duration:
        number = int(duration.group(1))
        if duration.group(2).startswith("week"):
            number *= 7
        entities["Duration"] = min(number, 14)

    date_patterns = [
        r"\b\d{1,2}[/-]\d{1,2}(?:[/-]\d{2,4})?\b",
        r"\b(?:january|february|march|april|may|june|july|august|september|october|november|december)(?:\s+\d{1,2}(?:st|nd|rd|th)?)?(?:,?\s+\d{4})?\b",
        r"\b(?:tomorrow|today|this weekend|next weekend|next week|next month|this month)\b",
    ]
    for pattern in date_patterns:
        match = re.search(pattern, lower)
        if match:
            entities["Date"] = match.group(0)
            break

    transports = {
        "Flight": ["flight", "plane", "air"],
        "Train": ["train", "railway"],
        "Bus": ["bus", "coach"],
        "Car": ["car", "self-drive", "driving"],
        "Bike": ["bike", "motorcycle"],
        "Taxi": ["taxi", "cab"],
    }
    for name, keywords in transports.items():
        if any(word in lower for word in keywords):
            entities["Transport Type"] = name
            break

    if re.search(r"\b(budget|cheap|affordable)\s+(hotel|stay)\b", lower):
        entities["Hotel"] = "Budget"
    elif re.search(r"\b(luxury|premium|five star|5 star)\b", lower):
        entities["Hotel"] = "Luxury"
    elif re.search(r"\b(resort|homestay|hostel)\b", lower):
        entities["Hotel"] = "Resort / Homestay / Hostel"
    elif re.search(r"\b(no preference|any hotel|any stay)\b", lower):
        entities["Hotel"] = "No preference"

    return entities


def recommend_destinations(budget: int):
    return sorted(
        [(name, data) for name, data in DESTINATIONS.items() if data["budget"] <= budget],
        key=lambda item: item[1]["budget"],
    )[:4]


def create_itinerary(destination: str, duration: int) -> str:
    data = DESTINATIONS[destination]
    places = data["attractions"]
    lines = []
    for day in range(1, duration + 1):
        first = ((day - 1) * 2) % len(places)
        second = (first + 1) % len(places)
        lines.append(f"**Day {day}:** {places[first]} and {places[second]}")
    return "\n\n".join(lines)


def initialize_state():
    if "messages" not in st.session_state:
        st.session_state.messages = [
            {
                "role": "assistant",
                "content": "Hello! I can help plan your trip. Tell me your destination or budget. You can choose Goa, Manali, Jaipur, Kerala, Ooty or Bengaluru.",
            }
        ]
    if "trip" not in st.session_state:
        st.session_state.trip = {
            "Destination": None,
            "Budget": None,
            "Date": None,
            "Duration": None,
            "Transport Type": None,
            "Hotel": None,
        }


def respond(message: str) -> str:
    trip = st.session_state.trip
    lower = message.lower().strip()
    intent = detect_intent(message)
    entities = extract_entities(message)

    if lower in {"reset", "start over", "restart"}:
        st.session_state.trip = {
            "Destination": None, "Budget": None, "Date": None,
            "Duration": None, "Transport Type": None, "Hotel": None,
        }
        return "No problem. Let's start again! Where would you like to travel, or what is your budget?"

    if lower in {"show plan", "my plan", "show details"}:
        return "Here are your current trip details:\n\n" + "\n".join(
            f"- **{key}:** {value if value is not None else 'Not provided'}"
            for key, value in trip.items()
        )

    if intent == "GOODBYE":
        return "Thank you for using the Travel Planning Chatbot. Have a wonderful trip!"

    if intent == "GREETING":
        return "Hello! Where would you like to travel? You can also tell me your budget."

    for key, value in entities.items():
        if key in trip:
            trip[key] = value

    # Budget-based recommendations when no destination is chosen.
    if trip["Budget"] is not None and trip["Destination"] is None and (
        intent == "BUDGET" or "recommend" in lower or "suggest" in lower
    ):
        options = recommend_destinations(trip["Budget"])
        if not options:
            return "Your budget is below the sample estimates. Consider a shorter trip, a nearby destination, or adjusting your budget."
        lines = ["Here are sample destinations within your budget (approximate cost per person):"]
        lines.extend([f"- **{name}:** ₹{data['budget']:,}" for name, data in options])
        lines.append("\nWhich destination would you like to choose?")
        return "\n".join(lines)

    if trip["Destination"] is None:
        return "Which destination are you interested in? Options include Goa, Manali, Jaipur, Kerala, Ooty and Bengaluru. You can also share your budget for suggestions."

    destination = trip["Destination"]
    data = DESTINATIONS[destination]

    if trip["Budget"] is None:
        return f"Nice choice! The sample estimate for {destination} is around ₹{data['budget']:,} per person. What is your total budget in rupees?"
    if trip["Date"] is None:
        return "When are you planning to travel? For example, October 20 or next weekend. If you haven't decided, type **skip date**."
    if trip["Date"] == "Not decided":
        pass
    if trip["Duration"] is None:
        return "How many days will you stay? For example, 3 days or 1 week. If unsure, type **skip duration**."
    if trip["Transport Type"] is None:
        return "Which transport do you prefer: bus, train, flight, car, bike or taxi? If undecided, type **skip transport**."
    if trip["Hotel"] is None:
        return "What accommodation do you prefer: budget hotel, luxury hotel, resort, homestay, or no preference?"

    # Once all information is available, provide a complete plan.
    budget_note = ""
    if trip["Budget"] < data["budget"]:
        budget_note = "\n\n**Budget note:** Your budget is below the sample estimate. Consider a shorter stay or a lower-cost destination."
    return (
        "## Your Travel Plan\n\n"
        f"- **Destination:** {destination}\n"
        f"- **Budget:** ₹{trip['Budget']:,}\n"
        f"- **Travel date:** {trip['Date']}\n"
        f"- **Duration:** {trip['Duration']} days\n"
        f"- **Transport:** {trip['Transport Type']}\n"
        f"- **Accommodation preference:** {trip['Hotel']}\n"
        f"- **Sample estimate:** ₹{data['budget']:,} per person\n\n"
        "### Suggested itinerary\n\n"
        + create_itinerary(destination, trip["Duration"])
        + f"\n\n**Food suggestion:** {data['food']}\n\n"
        f"**Accommodation guidance:** {data['hotel']}\n\n"
        "_These are illustrative suggestions, not live prices or bookings. Check current fares, availability and opening hours before travelling._"
        + budget_note
        + "\n\nYou can change any detail by sending a new message, type **show plan** to review your details, or **reset** to start over."
    )


initialize_state()

st.title("✈️ Travel Planning Chatbot")
st.caption("CA3 Project · Python · Intent detection · Entity extraction · Multi-turn conversation")
with st.expander("How to use"):
    st.write("Tell the chatbot your destination, budget, travel date, duration, transport and hotel preference. Type `show plan` to review details or `reset` to start over.")
    st.write("Supported destinations: Goa, Manali, Jaipur, Kerala, Ooty and Bengaluru.")
    st.info("The destination list and cost estimates are sample data. This app does not provide live prices or bookings.")

for message in st.session_state.messages:
    with st.chat_message(message["role"]):
        st.markdown(message["content"])

prompt = st.chat_input("Type your travel question...")
if prompt:
    st.session_state.messages.append({"role": "user", "content": prompt})
    with st.chat_message("user"):
        st.markdown(prompt)

    reply = respond(prompt)
    st.session_state.messages.append({"role": "assistant", "content": reply})
    with st.chat_message("assistant"):
        st.markdown(reply)

with st.sidebar:
    st.header("Your trip details")
    for key, value in st.session_state.trip.items():
        st.write(f"**{key}:** {value if value is not None else 'Not provided'}")
    if st.button("Reset conversation", use_container_width=True):
        st.session_state.messages = [
            {"role": "assistant", "content": "Hello! I can help plan your trip. Tell me your destination or budget. You can choose Goa, Manali, Jaipur, Kerala, Ooty or Bengaluru."}
        ]
        st.session_state.trip = {
            "Destination": None, "Budget": None, "Date": None,
            "Duration": None, "Transport Type": None, "Hotel": None,
        }
        st.rerun()
